"use strict";

const DEFAULT_SETTINGS = {
  baseUrl: "",
  apiToken: "",
  enabled: true,
};

async function ensureDefaults() {
  try {
    const { canvasSettings } = await chrome.storage.sync.get("canvasSettings");
    if (!canvasSettings || typeof canvasSettings !== "object") {
      await chrome.storage.sync.set({ canvasSettings: DEFAULT_SETTINGS });
      return;
    }
    const merged = {
      ...DEFAULT_SETTINGS,
      ...canvasSettings,
    };
    await chrome.storage.sync.set({ canvasSettings: merged });
  } catch (error) {
    // Ignore storage initialization issues to avoid hard-failing service worker startup.
  }
}

chrome.runtime.onInstalled.addListener(() => {
  void ensureDefaults();
});

chrome.runtime.onStartup.addListener(() => {
  void ensureDefaults();
});
